import os

# Creates relative file paths
file_path1 = os.path.join("docs", "poem.txt")
file_path2 = os.path.join("docs", "poem2.txt")

def read_text(file_path):
    """
    reads the poem in poem.txt line by line
    """
    with open(file_path, 'r') as f:
        lines = f.readlines() # read through each line and saves as a list
        for line in lines: # strips each line and prints it
            print(line.strip())
        return lines

def read_backwards():
    """
    reads the poem in poem.txt backwards
    """
    with open(file_path1, 'r') as f:
        lines = f.readlines() # read through each line and saves as a list
        for line in lines[::-1]:  # reverses the list
            print(line.strip())
        return lines[::-1]  #returns reversed lines

def write_text(lines):
        """
        Writes the reversed poem into poem2.txt
        """
        with open(file_path2, "w") as f:  # opens poem2.txt and writes in it.
            for line in lines:
                f.write(line.strip() + "\n")  # Writes each line reversed


def append_text():
    """
    appends to the poem the reason why this is my favorite poem and my name, saving the result in poem2.txt
    """
    with open(file_path2, "a") as f:  # Opens poem2.txt and appends to it.
        f.write("\n")  # Prints a blank line
        f.write("This is my favorite poem because we learnt it in high school and it brings back memories.")
        f.write("\n")  # Prints a blank line
        f.write("Miriam Stern\n")


print("\n")
print("----original----")
read_text(file_path1)
print("\n")
print("----reversed----")
reversed_lines = read_backwards()
write_text(reversed_lines)
print("\n")
print("----poem in poem2.txt----")
read_text(file_path2)
append_text()

